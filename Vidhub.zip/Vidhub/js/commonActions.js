function notSignedIn() {
    alert("You must be signed in to perform this action");
}
<?php
require_once("includes/header.php");
require_once("includes/footer.php");
require_once("includes/classes/VideoUploadData.php");
require_once("includes/classes/VideoProcessor.php");

if(!isset($_POST["uploadButton"])){
	echo "No file sent to the page";
	exit();
}


$videoUploadData = new VideoUploadData($_POST["video_url"], $_POST["video_thumbnail"], $_POST["cloud_id"], $_POST["duration"], $_POST["titleInput"], $_POST["descriptionInput"], $_POST["privacyInput"], $_POST["categoryInput"], $userLoggedInObj->getUsername());


$videoProcessor = new VideoProcessor($con);
$wasSuccessful = $videoProcessor->upload($videoUploadData);


if($wasSuccessful){
	
	echo "<div class='container' style='margin-top: 10px;'>
			Video has been successfully uploaded.
			</div>";
}

?>
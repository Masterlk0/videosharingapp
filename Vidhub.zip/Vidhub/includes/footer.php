	
    <!-- <footer class="footer-area">
        <div class="copywrite-area">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-12 col-sm-6">
                        <p class="copywrite-text">
                        	Made by Nabil Farhan. Original template from Colorlib.com
						</p>
                    </div>
                    <div class="col-12 col-sm-6">
                        <nav class="footer-nav">
                            <ul>
                                <li><a href="#">Go to Nabil's Website to check out other projects</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
	</footer> -->

	<script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
    <!-- Video Player -->
    <script src="//cdn.jsdelivr.net/npm/afterglowplayer@1.x"></script>

</body>
</html>
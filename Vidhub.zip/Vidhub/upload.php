<?php 
require_once("includes/header.php");
require_once("includes/classes/VideoDetailsFormProvider.php");

if(!$usernameLoggedIn){
    header("Location: signIn.php");
    exit();
}
?>

<section class="contact-area mb-80">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12">
               
                <div class="section-heading style-2">
                    <br>
                    <h4>Upload Video</h4>
                    <div class="line"></div>
                </div>
               
                <div class="contact-form-area mt-50">
                    <?php
                        $formProvider = new VideoDetailsFormProvider($con);
                        echo $formProvider->createUploadForm();
                    ?>
                </div>

                
                <div class="modal fade" id="loadingModal" tabindex="-1" role="dialog" aria-labelledby="loadingModal" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <img src="img/pleasewait2.gif" alt="Please wait...">
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>

<!-- Cloudinary Upload -->
<script src="https://widget.cloudinary.com/v2.0/global/all.js" type="text/javascript"></script>
<script type="text/javascript">
document.addEventListener("DOMContentLoaded", function() {
    var uploadButton = document.getElementById("upload_widget_opener");
    if (uploadButton) {
        uploadButton.addEventListener("click", function() {
            cloudinary.openUploadWidget({
                cloud_name: 'dmqhh28gb', // cloud name
                upload_preset: 'unsigned_upload', //  upload preset
                sources: ['local', 'url'],
                resourceType: 'video',
                multiple: false,
                styles: {
                    palette: {
                        window: "#222627",
                        sourceBg: "#222627",
                        windowBorder: "#DB4437",
                        tabIcon: "#FFFFFF",
                        inactiveTabIcon: "#8E9FBF",
                        menuIcons: "#DB4437",
                        link: "#DB4437",
                        action: "#DB4437",
                        inProgress: "#DB4437",
                        complete: "#33ff00",
                        error: "#EA2727",
                        textDark: "#000000",
                        textLight: "#FFFFFF"
                    },
                    fonts: {
                        default: null,
                        "'Poppins', sans-serif": {
                            url: "https://fonts.googleapis.com/css?family=Poppins",
                            active: true
                        }
                    }
                },
                thumbnailTransformation: { width: 300, height: 210 }
            }, function(error, result) {
                if (error) {
                    console.error('Upload Error:', error);
                    return;
                }

                if (result.event === "success") {
                    console.log('Upload Result:', result.info);

                    var video_url = result.info.secure_url;
                    var video_thumbnail = result.info.thumbnail_url;
                    var cloud_id = result.info.public_id;
                    var duration = result.info.duration;

                  
                    uploadButton.style.display = 'none';

                    
                    document.getElementById("video_url").value = video_url;
                    document.getElementById("video_thumbnail").value = video_thumbnail;
                    document.getElementById("cloud_id").value = cloud_id;
                    document.getElementById("duration").value = duration;
                }
            });
        }, false);
    }
});
</script>

<?php require_once("includes/footer.php"); ?>
